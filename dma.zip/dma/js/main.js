



var windowwidth = window.outerWidth;
if(windowwidth < 700){
var first_slide = document.querySelector('#firstslide');
first_slide.style.backgroundImage = `url('image/firstslide.jpg')`;
}else{

window.addEventListener('load',function(){
var slideimage = ['firstslide.jpg','thirdslidelast.jpg','dear.jpg','banner7.jpg'];
var imgboximage = ['firstslidebanner.png','slidebanner.png'];
var randomslidenumber = Math.floor(Math.random()*4);
var first_slide = document.querySelector('#firstslide');
var imgBox = document.querySelector('.imgBox');

first_slide.style.backgroundImage = `url('image/${slideimage[randomslidenumber]}')`;
imgBox.style.backgroundImage = `url('image/${imgboximage[randomslidenumber]}')`;
})
}



//downbuttonclick





$('document').ready(function(){    


$('.box h1').addClass('animationclass');
$('.box h2').addClass('animationclass');
$('.box p').addClass('animationclass');
$('.box .form-control').addClass('animationclass');
$('.box button').addClass('animationclass');


function anima() {
var carousel_item = $('.carousel-item').hasClass("active");
if(carousel_item){
var sib =  $('.carousel-inner .active');
sib.find("h3 , h1 , h5 , button").addClass('animationclass');
}else{
var sib =  $('.carousel-inner .active').next();
sib.find("h3 , h1 , h5 , button").addClass('ravi');
}
}

setInterval(() => {
anima();
}, 100);


//third calss active



//popup box
$('.requestpopup').click(function(){
$('#requestpopup').toggleClass('showpopup');
})


//popup box
$('#btnrequest','.btn-request').click(function(){
$('#requestpopup').toggleClass('showpopup');
})


//  setInterval(() => {
//    $('#requestpopup').addClass('showpopup');
//  }, 30000);



//popup box
$('.backdiv').click(function(){
$('#requestpopup').removeClass('showpopup');
})
//creative slide bar

$('.swiper-pagination-bullet').click(function(){
$('.swiper-slide-next').addClass('activeAnimation').siblings().removeClass('activeAnimation');
})


//nav 

$mobile_nav = $('.big-nav').clone().prop({class : 'mobile_nav d-lg-none'});

$('body').prepend($mobile_nav);

$('body').prepend('<button type="button" class="mobile-nav-toggle d-xl-none"><i class="icofont-navigation-menu"></i></button>');

$('.mobile-nav-toggle').click(function(){
$('.mobile_nav').toggleClass('active');
})

$('.mobile_nav .nav-link').click(function(){

    $(this).next().slideToggle(300);

// $('.mobile_nav .nav-link-dropdown').slideToggle(300);
})



//FREESEO


$('#chatnow').click(function(){
    console.log("rabs");
    $('.chatbox').slideToggle(300);
})
$('.box3').click(function(){
    $('.chatbox').slideToggle(300);
})

//navbar scroll function

// window.addEventListener('scroll',function () {
// console.log("ravihs");
// })



//dowbuttonlcick


})